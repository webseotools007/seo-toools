<?php

declare(strict_types=1);

namespace Arcanedev\SeoHelper\Exceptions;

/**
 * Class     InvalidArgumentException
 *
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
class InvalidArgumentException extends SeoHelperException {}
