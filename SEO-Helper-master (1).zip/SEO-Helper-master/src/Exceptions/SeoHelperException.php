<?php

declare(strict_types=1);

namespace Arcanedev\SeoHelper\Exceptions;

/**
 * Class     SeoHelperException
 *
 * @author   ARCANEDEV <arcanedev.maroc@gmail.com>
 */
abstract class SeoHelperException extends \Exception {}
